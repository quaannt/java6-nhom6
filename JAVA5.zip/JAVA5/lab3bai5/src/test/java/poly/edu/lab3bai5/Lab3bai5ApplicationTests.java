package poly.edu.lab3bai5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3bai5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
