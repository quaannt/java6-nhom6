package poly.edu.lab3bai5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3bai5Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab3bai5Application.class, args);
	}

}
