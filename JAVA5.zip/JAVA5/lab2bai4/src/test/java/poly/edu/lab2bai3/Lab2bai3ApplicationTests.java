package poly.edu.lab2bai3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2bai3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
