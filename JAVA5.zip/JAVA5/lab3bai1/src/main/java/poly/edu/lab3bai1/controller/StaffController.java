package poly.edu.lab3bai1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StaffController {

    @RequestMapping("/staff/detail")
    public String detail(Model model) {
        Staff staff = Staff.builder()
            .id("datmtpd10529@gmail.com")
            .fullname("mai thanh dat")
            .photo("photo.jpg")
            .gender(true)
            .level(2)
            .build();
        model.addAttribute("staff", staff);
        return "demo/staff-detail";
    }
}
