package poly.edu.lab3bai1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3bai1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
