package poly.edu.lab3bai4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3bai4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
