package poly.edu.lab3bai4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3bai4Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab3bai4Application.class, args);
	}

}
