package poly.edu.lab1bai4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1bai4Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab1bai4Application.class, args);
	}

}
