package poly.edu.lab4bai1;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.AccessLevel;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Staff {
    String id;
    String fullname;
    @Builder.Default
    String photo = "photo.jpg";
    @Builder.Default
    Boolean gender = null;
    @Builder.Default
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    Date birthday = new Date();
    @Builder.Default
    double salary = 12345.6789;
    @Builder.Default
    Integer level = 0;
}
