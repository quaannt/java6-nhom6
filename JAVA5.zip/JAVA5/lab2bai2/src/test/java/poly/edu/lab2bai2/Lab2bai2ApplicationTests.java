package poly.edu.lab2bai2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2bai2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
