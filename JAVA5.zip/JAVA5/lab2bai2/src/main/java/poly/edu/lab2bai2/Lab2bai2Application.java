package poly.edu.lab2bai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2bai2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab2bai2Application.class, args);
	}

}
