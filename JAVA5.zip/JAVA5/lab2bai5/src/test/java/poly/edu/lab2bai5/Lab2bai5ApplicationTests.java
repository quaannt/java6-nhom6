package poly.edu.lab2bai5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2bai5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
