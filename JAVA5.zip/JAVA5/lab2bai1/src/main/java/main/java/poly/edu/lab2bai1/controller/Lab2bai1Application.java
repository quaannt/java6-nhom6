package main.java.poly.edu.lab2bai1.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2bai1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab2bai1Application.class, args);
	}

}
