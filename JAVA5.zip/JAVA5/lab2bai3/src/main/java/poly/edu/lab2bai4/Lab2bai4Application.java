package poly.edu.lab2bai4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2bai4Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab2bai4Application.class, args);
	}

}
