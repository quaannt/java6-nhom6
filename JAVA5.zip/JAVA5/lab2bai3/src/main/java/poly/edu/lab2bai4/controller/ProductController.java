package poly.edu.lab2bai4.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProductController {

    @GetMapping("/product/form")
    public String form() {
        return "product/form";
    }

    @PostMapping("/product/save")
    public String save(Product product, Model model) {
        // Chia sẻ dữ liệu Product với view
        model.addAttribute("name", product.getName());
        model.addAttribute("price", product.getPrice());
        return "product/form";
    }
}
