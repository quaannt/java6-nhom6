package poly.edu.lab2bai4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2bai4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
