package poly.edu.lab3bai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3bai2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab3bai2Application.class, args);
	}

}
