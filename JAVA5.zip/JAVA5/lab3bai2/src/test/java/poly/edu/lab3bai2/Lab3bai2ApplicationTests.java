package poly.edu.lab3bai2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3bai2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
