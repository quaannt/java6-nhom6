package poly.edu.lab1bai5.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RectangleController {

    /**
     * Hiển thị form nhập chiều dài và chiều rộng.
     * Map với URL: /rectangle/form
     */
    @GetMapping("/rectangle/form")
    public String showForm() {
        return "rectangle-form"; // Trả về view rectangle-form.html
    }

    /**
     * Xử lý tính toán diện tích và chu vi.
     * Map với URL: /rectangle/calculate
     */
    @PostMapping("/rectangle/calculate")
    public String calculate(@RequestParam double width, @RequestParam double length, Model model) {
        // Tính toán
        double area = width * length;
        double perimeter = 2 * (width + length);

        // Chia sẻ dữ liệu với view
        model.addAttribute("width", width);
        model.addAttribute("length", length);
        model.addAttribute("area", area);
        model.addAttribute("perimeter", perimeter);

        return "rectangle-result"; // Trả về view rectangle-result.html
    }
}
