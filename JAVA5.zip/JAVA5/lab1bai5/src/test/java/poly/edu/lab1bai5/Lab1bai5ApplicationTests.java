package poly.edu.lab1bai5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1bai5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
