package poly.edu.lab4bai2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4bai2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
