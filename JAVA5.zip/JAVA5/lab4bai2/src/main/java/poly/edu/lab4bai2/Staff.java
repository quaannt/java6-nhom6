package poly.edu.lab4bai2;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Staff {
    private String id;
    private String fullname;
    private String photo = "photo.jpg";
    private Boolean gender = true;
    private Date birthday = new Date();
    private Double salary = 12345.6789;
    private Integer level = 0;
}

