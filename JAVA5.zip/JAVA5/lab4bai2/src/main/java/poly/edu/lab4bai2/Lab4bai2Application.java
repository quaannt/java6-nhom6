package poly.edu.lab4bai2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4bai2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab4bai2Application.class, args);
	}

}
